package com.fongmi.bear.impl;

public interface KeyDownImpl {

    void onSeeking(int time);

    void onSeekTo(int time);

    void onKeyDown();

    void onKeyCenter();
}
