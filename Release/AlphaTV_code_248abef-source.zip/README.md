# TV

### Based on CatVod  
https://github.com/CatVodTVOfficial/CatVodTVJarLoader

### Download
[TV](https://github.com/FongMi/TV/blob/main/release/leanback.apk?raw=true "leanback.apk")  
[Mobile](https://github.com/FongMi/TV/ "mobile.apk")  ...incoming

### Local Format
    file://cat.json

### Relative Path
    spider.jar
    /spider.jar
    ./spider.jar
    
### How to build
Use dev branch
