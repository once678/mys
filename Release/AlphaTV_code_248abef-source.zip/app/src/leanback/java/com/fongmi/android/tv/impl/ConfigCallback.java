package com.fongmi.android.tv.impl;

public interface ConfigCallback {

    void setConfig(String url);
}
